/* This example program demonstrates how to read and write a raw data in a serial port.
Reading the serial port is handled with timeout. */

#include <stdio.h> // standard input / output functions
#include <string.h> // string function definitions
#include <unistd.h> // UNIX standard function definitions
#include <fcntl.h> // File control definitions
#include <errno.h> // Error number definitions
#include <termios.h> // POSIX terminal control definitionss
#include <sys/time.h>   // time calls
#include <stdint.h>

int fd;
int read_port_flag = 0;
typedef struct serial_data_t
{
    uint8_t header; /* data length  */
    uint8_t data[8] ;//__attribute__((aligned(8)));
	uint8_t footer;
}serial_data_t __attribute__((aligned(4)));

int openPort(const char* port)
{
    fd = open(port, O_RDWR | O_NOCTTY | O_SYNC);
    if(fd == -1)
    {
        return (-1);
    }
    else
    {
        struct termios port_settings;
        bzero(&port_settings, sizeof(port_settings));

        /* set baud rates */
        cfsetispeed(&port_settings, B115200);
        cfsetospeed(&port_settings, B115200);

        /* enable the receiver and set local mode */
        port_settings.c_cflag |= (CLOCAL | CREAD);

        /* set no parity, stop bits, data bits */
        port_settings.c_cflag &= ~PARENB;
        port_settings.c_cflag &= ~CSTOPB;
        /* set character size as 8 bits */
        port_settings.c_cflag &= ~CSIZE;
        port_settings.c_cflag |= CS8;
        /* Raw input mode, sends the raw and unprocessed data  ( send as it is) */
        port_settings.c_lflag &= ~(ICANON | ECHO | ISIG);
        /* Raw output mode, sends the raw and unprocessed data  ( send as it is).
         * If it is in canonical mode and sending new line char then CR
         * will be added as prefix and send as CR LF
         */
        port_settings.c_oflag = ~OPOST;

        tcsetattr(fd, TCSANOW, &port_settings);

        return 0;
    }
}

/*int send_port(struct serial_data *send_data)
{
    if ((write(fd, send_data->data, send_data->len)) != send_data->len)
    {
         return (-1);
    }

    return 0;
}*/

void set_port_read_min_size(int min_size)
{
        struct termios settings;

        if (tcgetattr(fd, &settings))
        {
               /* handle error */
                return;
        }

        /* set the minimimum no. of chracters to read in each
         * read call.
         */
        settings.c_cc[VMIN]  = min_size;
        /* set “read timeout between characters” as 100 ms.
         * read returns either when the specified number of chars
         * are received or the timout occurs */
        settings.c_cc[VTIME] = 1; /* 1 * .1s */

        if (tcsetattr (fd, TCSANOW, &settings))
        {
                /* handle error */
        }
}

void read_port()
{
    struct serial_data_t recv_data;
    int recvbytes = 0;
    uint8_t headerByte __attribute__((aligned(1)));
    int maxfd = fd + 1;
    int index = 0;
    /* set the timeout as 1 sec for each read */
    struct timeval timeout = {1,0};
    fd_set readSet;

    /* set the “mininum characters to read” */
    set_port_read_min_size(32);
    read_port_flag = 1;

    while(read_port_flag)
    {
        FD_ZERO(&readSet);
        FD_SET(fd,&readSet);
        if(select(maxfd, &readSet, NULL, NULL, &timeout) > 0)
        {
            if (FD_ISSET(fd, &readSet))
            {
		printf("size = %d \n",sizeof(headerByte));
                recvbytes = read(fd, &headerByte,sizeof(headerByte));
		printf("Receive = %d \n",recvbytes);
                if(recvbytes)
                {
			printf("header byte = %c \n",(char)headerByte);
			if(headerByte == '{')
			{
				int receiveByte = read(fd, &recv_data, sizeof(serial_data_t));
				if (receiveByte)
				{
					for(index = 0; index < receiveByte; index++)
					    {
						printf("struct = %c \n",(char)recv_data.data[index]);
					    }
				}
				else
				{
					printf("don't have struct \n");
				}		
			}
			else
			{
				printf("not right header bytes\n");
			}
                }
                else
                {
                    /* handle error */
		    printf(" wrong receive \n");
                }
            }
        }
        /* select() – returns 0 on timeout and -1 on error condtion */
        if (!read_port_flag)
        {
            return;
        }
    }
    printf(" exit from read\n");
}

void close_port()
{
    close(fd);
}

int main(void) {

    openPort("/dev/ttyACM0");
    read_port();
/*while(1){
	    read_port();
}*/
    return 0;
}
